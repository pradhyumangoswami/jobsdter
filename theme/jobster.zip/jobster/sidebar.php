<?php
/**
 * @package WordPress
 * @subpackage Jobster
 */

dynamic_sidebar('pxp-main-widget-area');
?>
